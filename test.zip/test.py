import numpy as np
import torch
from scipy.io import loadmat
from tqdm import tqdm


def calculate_hamming(B1, B2):
    """
    :param B1:  vector [n]
    :param B2:  vector [r*n]
    :return: hamming distance [r]
    """
    leng = B2.shape[1]  # max inner product value
    distH = 0.5 * (leng - np.dot(B1, B2.transpose()))
    return distH

def calculate_top_map(qB, rB, query_label, retrieval_label, topk):
    """
    :param qB: {-1,+1}^{mxq} query bits
    :param rB: {-1,+1}^{nxq} retrieval bits
    :param query_label: {0,1}^{mxl} query label
    :param retrieval_label: {0,1}^{nxl} retrieval label
    :param topk:
    :return:
    """
    qB = qB.cpu().numpy()
    rB = rB.cpu().numpy()
    query_label = query_label.cpu().numpy()
    retrieval_label = retrieval_label.cpu().numpy()

    num_query = query_label.shape[0]
    topkmap = 0
    for iter in tqdm(range(num_query)):
        gnd = (np.dot(query_label[iter, :], retrieval_label.transpose()) > 0).astype(np.float32)
        hamm = calculate_hamming(qB[iter, :], rB)
        ind = np.argsort(hamm)
        gnd = gnd[ind]

        tgnd = gnd[0:topk]
        tsum = np.sum(tgnd)
        if tsum == 0:
            continue
        count = np.linspace(1, tsum, int(tsum))
        tindex = np.asarray(np.where(tgnd == 1)) + 1.0
        topkmap_ = np.mean(count / (tindex))
        topkmap = topkmap + topkmap_
    topkmap = topkmap / num_query
    return topkmap

bits = [64, 32, 16]
datasets = ['cifar10', 'imagenet', 'coco']
for dataset in datasets:
    for bit in bits:
        if dataset == "coco":
            topk = 5000
        if dataset == "cifar10":
            topk = -1
        if dataset == "imagenet":
            topk = 1000
        mat_file = "./{}-ours-{}-i2i.mat".format(bit, dataset)

        result = loadmat(mat_file)
        # 查询集和检索集保存反了，反着读就行
        qBX = torch.from_numpy(result['g_c'][:])  # image query
        rBX = torch.from_numpy(result['q_c'][:])  # image retrieval
        query_L = torch.from_numpy(result['g_y'][:])  # query label
        retrieval_L = torch.from_numpy(result['q_y'][:])  # retrieval label

        map_i2i = calculate_top_map(qB=qBX, rB=rBX, query_label=query_L, retrieval_label=retrieval_L, topk=topk)

        print("dataset: {}, bits: {}, map_i2i: {:.4f}".format(dataset, bit, round(map_i2i.item(), 4)))
